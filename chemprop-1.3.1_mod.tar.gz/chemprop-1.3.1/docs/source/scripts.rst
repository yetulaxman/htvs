.. _scripts:

Useful Scripts
==============

Additional useful scripts for working with property prediction datasets are contained in `<https://github.com/chemprop/chemprop/tree/master/scripts>`_.
